'use strict';
var Alexa = require('alexa-sdk');
var http = require('http');
var APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

var textGot = "giraffe";

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetText');
    },
    'SpeakTextIntent': function () {
        this.emit('GetText');
    },
    'GetText': function () {
        this.emit(':tell', textGot);
    },
    'AMAZON.HelpIntent': function () {
        
    },
    'AMAZON.CancelIntent': function () {

    },
    'AMAZON.StopIntent': function () {
       
    }
};
