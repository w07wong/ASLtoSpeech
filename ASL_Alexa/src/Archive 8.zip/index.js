'use strict';
var Alexa = require('alexa-sdk');
var http = require('http');
var APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

var result = "";

var options = {
  host: 'www.google.com',
  port: 80,
  path: '/upload',
  method: 'POST'
};

var req = http.request(options, function(res) {
 
  res.setEncoding('utf8');
  res.on('data', function (chunk) {
  });
});

// write data to request body
result = 'data\n';
req.end();

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetText');
    },
    'SpeakTextIntent': function () {
        this.emit('GetText');
    },
    'GetText': function () {
        this.emit(':tell', result);
    },
    'AMAZON.HelpIntent': function () {
    },
    'AMAZON.CancelIntent': function () {
    },
    'AMAZON.StopIntent': function () {
    }
};
