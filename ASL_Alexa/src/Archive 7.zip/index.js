'use strict';
var Alexa = require('alexa-sdk');
var request = require('request');
var APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

var result = "";

var url = "https://stormy-tor-35371.herokuapp.com/"

request(url, function(err,resp, body) {
    if(err) {
        result= "error";
    } else {
        result = "true";
    }
})

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetText');
    },
    'SpeakTextIntent': function () {
        this.emit('GetText');
    },
    'GetText': function () {
        this.emit(':tell', result);
    },
    'AMAZON.HelpIntent': function () {
    },
    'AMAZON.CancelIntent': function () {
    },
    'AMAZON.StopIntent': function () {
    }
};
